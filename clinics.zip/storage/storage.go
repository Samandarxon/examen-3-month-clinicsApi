package storage

import (
	"context"

	"github.com/Samandarxon/examen_3-month/clinics/models"
)

type StorageI interface {
	Branch() BranchRepoI
	Client() ClientRepoI
	ComingTable() ComingTableRepoI
}

type BranchRepoI interface {
	Create(ctx context.Context, req models.CreateBranch) (*models.Branch, error)
	GetList(ctx context.Context, req models.GetListBranchRequest) (*models.GetListBranchResponse, error)
	GetById(ctx context.Context, req models.BranchPrimaryKey) (*models.Branch, error)
	Update(ctx context.Context, req models.UpdateBranch) (*models.Branch, error)
	Delete(ctx context.Context, req models.BranchPrimaryKey) error
}

type ClientRepoI interface {
	Create(ctx context.Context, req models.CreateClient) (*models.Client, error)
	GetList(ctx context.Context, req models.GetListClientRequest) (*models.GetListClientResponse, error)
	GetById(ctx context.Context, req models.ClientPrimaryKey) (*models.Client, error)
	Update(ctx context.Context, req models.UpdateClient) (*models.Client, error)
	Delete(ctx context.Context, req models.ClientPrimaryKey) error
}

type ComingTableRepoI interface {
	Create(ctx context.Context, req models.CreateComingTable) (*models.ComingTable, error)
	GetList(ctx context.Context, req models.GetListComingTableRequest) (*models.GetListComingTableResponse, error)
	GetById(ctx context.Context, req models.ComingTablePrimaryKey) (*models.ComingTable, error)
	Update(ctx context.Context, req models.UpdateComingTable) (*models.ComingTable, error)
	Delete(ctx context.Context, req models.ComingTablePrimaryKey) error
}
