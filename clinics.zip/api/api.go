package api

import (
	"github.com/gin-gonic/gin"

	"github.com/Samandarxon/examen_3-month/clinics/api/handler"
	"github.com/Samandarxon/examen_3-month/clinics/config"
	"github.com/Samandarxon/examen_3-month/clinics/storage"

	_ "github.com/Samandarxon/examen_3-month/clinics/api/docs"
	swaggerfiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"
)

func SetUpAPI(r *gin.Engine, cfg *config.Config, strg storage.StorageI) {
	handler := handler.NewHandler(cfg, strg)

	r.Use(customCORSMiddleware())

	//	@title		MARKET SYSTEM API
	//	@version	1.0
	//	@host		localhost:8080
	//	@BasePath	/api/v1
	v1 := r.Group("/api/v1")
	{
		// Branch
		v1.POST("/branch", handler.CreateBranch)
		v1.GET("/branch", handler.GetListBranch)
		v1.PUT("/branch/:id", handler.UpdateBranch)
		v1.GET("/branch/:id", handler.GetByIdBranch)
		v1.DELETE("/branch/:id", handler.DeleteBranch)

		// User
		v1.POST("/user", handler.CreateClient)
		v1.GET("/user", handler.GetListClient)
		v1.PUT("/user/:id", handler.UpdateClient)
		v1.GET("/user/:id", handler.GetByIdClient)
		v1.DELETE("/user/:id", handler.DeleteClient)

		// ComingTable
		v1.POST("/coming", handler.CreateComingTable)
		v1.GET("/coming", handler.GetListComingTable)
		v1.PUT("/coming/:id", handler.UpdateComingTable)
		v1.GET("/coming/:id", handler.GetByIdComingTable)
		v1.DELETE("/coming/:id", handler.DeleteComingTable)

		// // Supplier
		// v1.POST("/supplier", handler.CreateSuplier)
		// v1.GET("/supplier", handler.GetListSuplier)
		// v1.PUT("/supplier/:id", handler.UpdateSuplier)
		// v1.GET("/supplier/:id", handler.GetByIdSuplier)
		// v1.DELETE("/supplier/:id", handler.DeleteSuplier)

	}

	r.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerfiles.Handler))

}

func customCORSMiddleware() gin.HandlerFunc {

	return func(c *gin.Context) {

		c.Header("Access-Control-Allow-Origin", "*")
		c.Header("Access-Control-Allow-Credentials", "true")
		c.Header("Access-Control-Allow-Methods", "POST, OPTIONS, GET, PUT, PATCH, DELETE, HEAD")
		c.Header("Access-Control-Allow-Headers", "Password, Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With")
		c.Header("Access-Control-Max-Age", "3600")

		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}

		c.Next()
	}
}
